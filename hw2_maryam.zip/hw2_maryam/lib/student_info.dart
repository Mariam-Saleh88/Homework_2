import 'package:flutter/material.dart';
import 'package:hw2_maryam/student.dart';
class StudentInfo extends StatelessWidget {
  final Student student;

  const StudentInfo(this.student, {   Key? key,   required  id,   required  name,   required  image,   required  grade, }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return
      Container(

          padding: const EdgeInsets.all(8),
          height: 120,
          color: Colors.black12,
          child: Card(
              child: Row(
                  children: [
              Container(
              padding: EdgeInsets.only(left: 30, right: 15),
            child: CircleAvatar(

              backgroundImage: AssetImage('images/${student.image}'),
              radius: 25,
              ),

          ),


                    Expanded(child: Container(padding: EdgeInsets.all(4),
                      child: Column(
                        children: [

                          Row(
                            children: [
                              const Text('Id: ', style: TextStyle(
                                  color: Colors.pink),),
                              Text(student.id, style: const TextStyle(
                                color: Colors.black),),
                            ],
                          ),
                          Row(
                            children: [
                              const Text('Name: ', style: TextStyle(
                                  color: Colors.pink),),
                              Text(student.name, style: const TextStyle(
                                   color: Colors.black),),
                            ],
                          ),
                          Row(
                            children: [
                              const Text('Grade: ', style: TextStyle(
                                   color: Colors.pink),),
                              Text(student.grade, style: const TextStyle(
                                 color: Colors.black),)
                            ],

                          ),

                       Row(
                         children: [
                           IconButton(icon: Icon(Icons.add),onPressed: (){ },),
                           IconButton(icon: Icon(Icons.remove),onPressed: (){ },),
                         ],
                       )





                        ],
                      ),
                    ),
                    )
                  ]
              )
          )
      );
  }
}
