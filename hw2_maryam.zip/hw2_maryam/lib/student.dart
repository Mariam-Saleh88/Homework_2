class Student {
  String _id;
  String _name;
  String _image;
  String _grade;

  Student(this._id, this._name, this._image, this._grade);

  String get grade => _grade;

  set grade(String value) {
    _grade = value;
  }

  String get image => _image;

  set image(String value) {
    _image = value;
  }

  String get name => _name;

  set name(String value) {
    _name = value;
  }

  String get id => _id;

  set id(String value) {
    _id = value;
  }

  @override
  String toString() {
    return 'Student{_id: $_id, _name: $_name, _image: $_image, _grade: $_grade}';
  }
}