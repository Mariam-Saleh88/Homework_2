import 'package:flutter/material.dart';
import 'package:hw2_maryam/student.dart';
import 'student_info.dart';

void main() {
  runApp(const MyApp());
}
List<Student>students=[
  Student('1234','Maryam','img1.png','90.2'),
  Student('5678','Anwar','img2.jpg','85.5'),
  Student('9876','Rahma','img3.jpg','89.9'),
];
class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner:false,
      title: 'List of students',
      home: Scaffold(
        appBar: AppBar(
          title: const Text('information about students'),
          centerTitle: true,
        ),
        body: Column(
          children: [
            Text('Students List: '),
            Expanded(
              child:
              ListView.builder(
                  itemBuilder: (context, index) => StudentInfo(students[index], id: students[index].id,name: students[index].name,image: students[index].image,grade: students[index].grade,),
                  itemCount: students.length
              ),
            ),
          ],
        ),
      ),
    );
  }
}