package com.example.hw2_maryam

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
